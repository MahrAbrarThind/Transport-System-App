﻿namespace Bussiness_Application_1
{
    partial class UserPayFarePanel
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            PayFareDoneBtn = new Button();
            label2 = new Label();
            userPayFaretxtBox = new TextBox();
            label1 = new Label();
            SuspendLayout();
            // 
            // PayFareDoneBtn
            // 
            PayFareDoneBtn.Location = new Point(409, 415);
            PayFareDoneBtn.Name = "PayFareDoneBtn";
            PayFareDoneBtn.Size = new Size(75, 23);
            PayFareDoneBtn.TabIndex = 7;
            PayFareDoneBtn.Text = "Done";
            PayFareDoneBtn.UseVisualStyleBackColor = true;
            PayFareDoneBtn.Click += PayFareDoneBtn_Click;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Consolas", 21.75F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point);
            label2.Location = new Point(157, 87);
            label2.Name = "label2";
            label2.Size = new Size(223, 34);
            label2.TabIndex = 6;
            label2.Text = "Pay Fare Page";
            // 
            // userPayFaretxtBox
            // 
            userPayFaretxtBox.Location = new Point(336, 252);
            userPayFaretxtBox.Name = "userPayFaretxtBox";
            userPayFaretxtBox.Size = new Size(100, 23);
            userPayFaretxtBox.TabIndex = 5;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Consolas", 12F, FontStyle.Bold, GraphicsUnit.Point);
            label1.Location = new Point(25, 256);
            label1.Name = "label1";
            label1.Size = new Size(234, 19);
            label1.TabIndex = 4;
            label1.Text = "Enter the amount of fare:";
            // 
            // UserPayFarePanel
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            Controls.Add(PayFareDoneBtn);
            Controls.Add(label2);
            Controls.Add(userPayFaretxtBox);
            Controls.Add(label1);
            Name = "UserPayFarePanel";
            Size = new Size(509, 525);
            Load += UserPayFarePanel_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button PayFareDoneBtn;
        private Label label2;
        private TextBox userPayFaretxtBox;
        private Label label1;
    }
}
