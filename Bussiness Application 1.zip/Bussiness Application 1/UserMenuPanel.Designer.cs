﻿namespace Bussiness_Application_1
{
    partial class UserMenuPanel
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            cancelTicketBtn = new Button();
            exitBtn = new Button();
            UserMenulbl = new Label();
            FeedbackBtn = new Button();
            seeFareBtn = new Button();
            BookTicketBtn = new Button();
            userdataBtn = new Button();
            changepasswordBtn = new Button();
            SuspendLayout();
            // 
            // cancelTicketBtn
            // 
            cancelTicketBtn.Location = new Point(87, 181);
            cancelTicketBtn.Name = "cancelTicketBtn";
            cancelTicketBtn.Size = new Size(117, 28);
            cancelTicketBtn.TabIndex = 13;
            cancelTicketBtn.Text = "CancelTicket";
            cancelTicketBtn.UseVisualStyleBackColor = true;
            cancelTicketBtn.Click += cancelTicketBtn_Click;
            // 
            // exitBtn
            // 
            exitBtn.Location = new Point(87, 442);
            exitBtn.Name = "exitBtn";
            exitBtn.Size = new Size(117, 28);
            exitBtn.TabIndex = 12;
            exitBtn.Text = "Exit";
            exitBtn.UseVisualStyleBackColor = true;
            exitBtn.Click += exitBtn_Click;
            // 
            // UserMenulbl
            // 
            UserMenulbl.AutoSize = true;
            UserMenulbl.Font = new Font("Comic Sans MS", 21.75F, FontStyle.Bold, GraphicsUnit.Point);
            UserMenulbl.Location = new Point(64, 43);
            UserMenulbl.Name = "UserMenulbl";
            UserMenulbl.Size = new Size(154, 40);
            UserMenulbl.TabIndex = 11;
            UserMenulbl.Text = "UserMenu";
            // 
            // FeedbackBtn
            // 
            FeedbackBtn.Location = new Point(87, 284);
            FeedbackBtn.Name = "FeedbackBtn";
            FeedbackBtn.Size = new Size(117, 27);
            FeedbackBtn.TabIndex = 10;
            FeedbackBtn.Text = "GiveFeedback";
            FeedbackBtn.UseVisualStyleBackColor = true;
            FeedbackBtn.Click += FeedbackBtn_Click;
            // 
            // seeFareBtn
            // 
            seeFareBtn.Location = new Point(87, 231);
            seeFareBtn.Name = "seeFareBtn";
            seeFareBtn.Size = new Size(117, 28);
            seeFareBtn.TabIndex = 9;
            seeFareBtn.Text = "SeeFare";
            seeFareBtn.UseVisualStyleBackColor = true;
            seeFareBtn.Click += seeFareBtn_Click;
            // 
            // BookTicketBtn
            // 
            BookTicketBtn.Location = new Point(87, 128);
            BookTicketBtn.Name = "BookTicketBtn";
            BookTicketBtn.Size = new Size(117, 28);
            BookTicketBtn.TabIndex = 8;
            BookTicketBtn.Text = "BookTicket";
            BookTicketBtn.UseVisualStyleBackColor = true;
            BookTicketBtn.Click += BookTicketBtn_Click;
            // 
            // userdataBtn
            // 
            userdataBtn.Location = new Point(87, 335);
            userdataBtn.Name = "userdataBtn";
            userdataBtn.Size = new Size(117, 28);
            userdataBtn.TabIndex = 14;
            userdataBtn.Text = "AboutMe";
            userdataBtn.UseVisualStyleBackColor = true;
            userdataBtn.Click += userdataBtn_Click;
            // 
            // changepasswordBtn
            // 
            changepasswordBtn.Location = new Point(87, 393);
            changepasswordBtn.Name = "changepasswordBtn";
            changepasswordBtn.Size = new Size(117, 29);
            changepasswordBtn.TabIndex = 15;
            changepasswordBtn.Text = "ChangePassword";
            changepasswordBtn.UseVisualStyleBackColor = true;
            changepasswordBtn.Click += changepasswordBtn_Click;
            // 
            // UserMenuPanel
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackgroundImage = Properties.Resources.copy;
            Controls.Add(changepasswordBtn);
            Controls.Add(userdataBtn);
            Controls.Add(cancelTicketBtn);
            Controls.Add(exitBtn);
            Controls.Add(UserMenulbl);
            Controls.Add(FeedbackBtn);
            Controls.Add(seeFareBtn);
            Controls.Add(BookTicketBtn);
            Name = "UserMenuPanel";
            Size = new Size(287, 535);
            Load += UserMenuPanel_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button cancelTicketBtn;
        private Button exitBtn;
        private Label UserMenulbl;
        private Button FeedbackBtn;
        private Button seeFareBtn;
        private Button BookTicketBtn;
        private Button userdataBtn;
        private Button changepasswordBtn;
    }
}
