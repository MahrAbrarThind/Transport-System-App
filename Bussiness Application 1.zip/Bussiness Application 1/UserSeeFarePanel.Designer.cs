﻿namespace Bussiness_Application_1
{
    partial class UserSeeFarePanel
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            UserSeeFareDataGridView = new DataGridView();
            ((System.ComponentModel.ISupportInitialize)UserSeeFareDataGridView).BeginInit();
            SuspendLayout();
            // 
            // UserSeeFareDataGridView
            // 
            UserSeeFareDataGridView.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            UserSeeFareDataGridView.Location = new Point(78, 134);
            UserSeeFareDataGridView.Name = "UserSeeFareDataGridView";
            UserSeeFareDataGridView.RowTemplate.Height = 25;
            UserSeeFareDataGridView.Size = new Size(410, 298);
            UserSeeFareDataGridView.TabIndex = 1;
            // 
            // UserSeeFarePanel
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            Controls.Add(UserSeeFareDataGridView);
            Name = "UserSeeFarePanel";
            Size = new Size(566, 567);
            Load += UserSeeFarePanel_Load;
            ((System.ComponentModel.ISupportInitialize)UserSeeFareDataGridView).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private DataGridView UserSeeFareDataGridView;
    }
}
