﻿using Bussiness_Application_1.BL;
using Bussiness_Application_1.DL;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Bussiness_Application_1
{
    public partial class ViewFeedBackPanel : UserControl
    {
        Panel panel1;
        Panel panel2;
        AdminBL admin;
        public ViewFeedBackPanel(Panel panel1, Panel panel2, AdminBL admin)
        {
            this.panel1 = panel1;
            this.panel2 = panel2;
            this.admin = admin;
            InitializeComponent();
        }

        private void adminSeeFeedbacktxtBox_TextChanged(object sender, EventArgs e)
        {

        }

        private void ViewFeedBackPanel_Load(object sender, EventArgs e)
        {
            foreach(var a in PersonDL.feedback_list)
            {
                textBox1.Text += a.get_feedback() + Environment.NewLine;   
            }

        }
    }
}
