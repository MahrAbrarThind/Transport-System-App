﻿using Bussiness_Application_1.BL;
using Bussiness_Application_1.DL;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Security.Cryptography.Pkcs;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Bussiness_Application_1
{
    public partial class AdminSeeFarePanel : UserControl
    {
        DataTable table = new DataTable();
        DataTable table1 = new DataTable();
        Panel panel1;
        Panel panel2;
        AdminBL admin;
        public AdminSeeFarePanel(Panel panel1, Panel panel2, AdminBL admin)
        {
            InitializeComponent();
            this.panel1 = panel1;
            this.panel2 = panel2;
            this.admin = admin;
        }

        private void AdminSeeFarePanel_Load(object sender, EventArgs e)
        {

            table.Columns.Add("City", typeof(string));
            table.Columns.Add("High Fare", typeof(int));
            table.Columns.Add("Low Fare", typeof(int));
            table.Columns.Add("Seats", typeof(int));
            dataGridView1.DataSource = table;
            foreach (var a in TicketDL.Available_ticket_list)
            {
                table.Rows.Add(a.get_city(), a.get_high_fare(), a.get_low_fare(), a.get_seats());
            }
            table1.Columns.Add("Booked City", typeof(string));
            table1.Columns.Add("Booked Seats", typeof(int));
            dataGridView2.DataSource = table1;
            foreach (var a in PersonDL.person_list)
            {
                if (a is UserBL user)
                {
                    foreach (var b in user.booked_seats_list)
                    {
                        table1.Rows.Add(b.get_city(), b.get_seats());
                    }
                }
            }
        }
    }
}
