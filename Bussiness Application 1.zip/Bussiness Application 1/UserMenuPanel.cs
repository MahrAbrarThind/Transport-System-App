﻿using Bussiness_Application_1.BL;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Bussiness_Application_1
{
    public partial class UserMenuPanel : UserControl
    {
        Panel panel1;
        Panel panel2;
        UserBL user;
        public UserMenuPanel(Panel panel1, Panel panel2, UserBL user)
        {
            this.panel1 = panel1;
            this.panel2 = panel2;
            this.user = user;
            InitializeComponent();
        }

        private void exitBtn_Click(object sender, EventArgs e)
        {
            SignInSignUpPanel signInSignUpPanel = new SignInSignUpPanel(panel1, panel2);
            panel1.Controls.Clear();
            panel1.Controls.Add(signInSignUpPanel);
        }

        private void BookTicketBtn_Click(object sender, EventArgs e)
        {
            BookTicketPanel bookTicketPanel = new BookTicketPanel(panel1, panel2, user);
            panel2.Controls.Clear();
            panel2.Controls.Add(bookTicketPanel);
        }

        private void FeedbackBtn_Click(object sender, EventArgs e)
        {
            GiveFeedBackPanel giveFeedBackPanel = new GiveFeedBackPanel(panel1, panel2, user);
            panel2.Controls.Clear();
            panel2.Controls.Add(giveFeedBackPanel);
        }

        private void seeFareBtn_Click(object sender, EventArgs e)
        {
            UserSeeFarePanel userSeeFarePanel = new UserSeeFarePanel(panel1, panel2, user);
            panel2.Controls.Clear();
            panel2.Controls.Add(userSeeFarePanel);
        }

        private void cancelTicketBtn_Click(object sender, EventArgs e)
        {
            CancelTicketPanel cancelTicketPanel = new CancelTicketPanel(panel1, panel2, user);
            panel2.Controls.Clear();
            panel2.Controls.Add(cancelTicketPanel);
        }

        private void userdataBtn_Click(object sender, EventArgs e)
        {
            UserSeeDataPanel userSeeDataPanel = new UserSeeDataPanel(panel1, panel2, user);
            panel2.Controls.Clear();
            panel2.Controls.Add(userSeeDataPanel);
        }

        private void changepasswordBtn_Click(object sender, EventArgs e)
        {
            ChangePasswordPanel changePasswordPanel = new ChangePasswordPanel(panel1, panel2, user);
            panel2.Controls.Clear();
            panel2.Controls.Add(changePasswordPanel);
        }

        private void UserMenuPanel_Load(object sender, EventArgs e)
        {

        }
    }
}
