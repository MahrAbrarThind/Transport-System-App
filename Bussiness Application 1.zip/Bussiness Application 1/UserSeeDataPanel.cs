﻿using Bussiness_Application_1.BL;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Bussiness_Application_1
{
    public partial class UserSeeDataPanel : UserControl
    {
        Panel panel1;
        Panel panel2;
        UserBL user;
        DataTable table = new DataTable();
        DataTable table1 = new DataTable();

        public UserSeeDataPanel(Panel panel1, Panel panel2, UserBL user)
        {
            this.panel1 = panel1;
            this.panel2 = panel2;
            this.user = user;
            InitializeComponent();
        }

        private void UserSeeDataPanel_Load(object sender, EventArgs e)
        {
            table.Columns.Add("UserName", typeof(string));
            table.Columns.Add("UserPassword", typeof(string));
            dataGridView1.DataSource = table;
            table.Rows.Add(user.getname(), user.getpassword());

            table1.Columns.Add("BookedCity", typeof(string));
            table1.Columns.Add("BookedSeats", typeof(int));
            dataGridView2.DataSource = table1;
            foreach(var a in user.booked_seats_list)
            {
                table1.Rows.Add(a.get_city(), a.get_seats());
            }
        }
    }
}
