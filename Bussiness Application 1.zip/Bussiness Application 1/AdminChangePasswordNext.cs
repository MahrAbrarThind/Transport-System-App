﻿using Bussiness_Application_1.BL;
using Bussiness_Application_1.DL;
using Microsoft.VisualBasic.ApplicationServices;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Bussiness_Application_1
{
    public partial class AdminChangePasswordNext : UserControl
    {
        Panel panel1;
        Panel panel2;
        AdminBL admin;
        public AdminChangePasswordNext(Panel panel1, Panel panel2, AdminBL admin)
        {
            this.panel1 = panel1;
            this.panel2 = panel2;
            this.admin = admin;
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string password = textBox1.Text;
            if (string.IsNullOrEmpty(password))
            {
                MessageBox.Show("TextBox is Empty");
            }
            else
            {
                admin.set_password(password);
                MessageBox.Show("Password change successfull");
            }
            PersonDL.storeCredentials(admin);
        }
    }
}
