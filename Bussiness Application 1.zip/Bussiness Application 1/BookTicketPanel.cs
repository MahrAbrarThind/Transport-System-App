﻿using Bussiness_Application_1.BL;
using Bussiness_Application_1.DL;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Bussiness_Application_1
{
    public partial class BookTicketPanel : UserControl
    {
        Panel panel1;
        Panel panel2;
        UserBL user;
        public BookTicketPanel(Panel panel1,Panel panel2,UserBL user)
        {
            this.panel1 = panel1;
            this.panel2 = panel2;
            this.user = user;
            InitializeComponent();
        }

        private void CityComboBox_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void SeatsComboBox_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void DoneBtn_Click(object sender, EventArgs e)
        {
            string city = CityComboBox.Text;
            int seats = int.Parse(SeatsComboBox.Text);
            string choosed_fare=FareComboBox.Text;
            
            int user_fare = TicketDL.fare_of_user(city, choosed_fare, seats);
            BookedSeatsBL booked = new BookedSeatsBL(user_fare,choosed_fare,city,seats);
            user.add_into_booked_seats_list(booked);
            TicketDL.seats_decreased(booked);
            TicketDL.storeCredentials();
            TicketDL.storeCredentials2();
            UserPayFarePanel userPayFarePanel = new UserPayFarePanel(panel1, panel2, booked,user);
            MessageBox.Show("your total fare is ",user_fare.ToString());
            panel2.Controls.Clear();
            panel2.Controls.Add(userPayFarePanel);
            panel1.Controls.Clear();

        }

        private void BookTicketPanel_Load(object sender, EventArgs e)
        {
            foreach(var a in TicketDL.Available_ticket_list)
            {
                CityComboBox.Items.Add(a.get_city());
            }

        }
    }
}
