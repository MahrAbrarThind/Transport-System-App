﻿namespace Bussiness_Application_1.BL
{
    partial class GiveFeedBackPanel
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            FeedbackDoneBtn = new Button();
            label2 = new Label();
            userGiveFeedbacktxtBox = new TextBox();
            label1 = new Label();
            SuspendLayout();
            // 
            // FeedbackDoneBtn
            // 
            FeedbackDoneBtn.Location = new Point(380, 415);
            FeedbackDoneBtn.Name = "FeedbackDoneBtn";
            FeedbackDoneBtn.Size = new Size(75, 23);
            FeedbackDoneBtn.TabIndex = 11;
            FeedbackDoneBtn.Text = "Done";
            FeedbackDoneBtn.UseVisualStyleBackColor = true;
            FeedbackDoneBtn.Click += FeedbackDoneBtn_Click;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Consolas", 21.75F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point);
            label2.Location = new Point(137, 56);
            label2.Name = "label2";
            label2.Size = new Size(223, 34);
            label2.TabIndex = 10;
            label2.Text = "FeedBack Page";
            // 
            // userGiveFeedbacktxtBox
            // 
            userGiveFeedbacktxtBox.Location = new Point(223, 221);
            userGiveFeedbacktxtBox.Multiline = true;
            userGiveFeedbacktxtBox.Name = "userGiveFeedbacktxtBox";
            userGiveFeedbacktxtBox.Size = new Size(232, 165);
            userGiveFeedbacktxtBox.TabIndex = 9;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Consolas", 12F, FontStyle.Bold, GraphicsUnit.Point);
            label1.Location = new Point(5, 225);
            label1.Name = "label1";
            label1.Size = new Size(189, 19);
            label1.TabIndex = 8;
            label1.Text = "Enter Your Feedback:";
            // 
            // GiveFeedBackPanel
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            Controls.Add(FeedbackDoneBtn);
            Controls.Add(label2);
            Controls.Add(userGiveFeedbacktxtBox);
            Controls.Add(label1);
            Name = "GiveFeedBackPanel";
            Size = new Size(556, 562);
            Load += GiveFeedBackPanel_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button FeedbackDoneBtn;
        private Label label2;
        private TextBox userGiveFeedbacktxtBox;
        private Label label1;
    }
}
