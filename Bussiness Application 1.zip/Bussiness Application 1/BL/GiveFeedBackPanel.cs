﻿using Bussiness_Application_1.DL;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Bussiness_Application_1.BL
{
    public partial class GiveFeedBackPanel : UserControl
    {
        Panel panel1;
        Panel panel2;
        UserBL user;
        public GiveFeedBackPanel(Panel panel1, Panel panel2, UserBL user)
        {

            InitializeComponent();
            this.panel1 = panel1;
            this.panel2 = panel2;
            this.user = user;
        }

        private void FeedbackDoneBtn_Click(object sender, EventArgs e)
        {
            string feedback = userGiveFeedbacktxtBox.Text;
            UserBL user = new UserBL(feedback);
            PersonDL.add_feedback(user);

        }

        private void GiveFeedBackPanel_Load(object sender, EventArgs e)
        {

        }
    }
}
