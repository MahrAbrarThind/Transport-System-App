﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bussiness_Application_1.BL
{
    public class PersonBL
    {
        protected string name;
        protected string password;
        protected string role;

        public PersonBL(string name, string password, string role)
        {
            this.name = name;
            this.password = password;
            this.role = role;
        }
        public string getname()
        {
            return name;
        }
        public string getpassword()
        {
            return password;
        }
        public string getrole()
        {
            return role;
        }
        public void set_name(string name)
        {
            this.name = name;
        }
        public void set_password(string password)
        {
            this.password = password;
        }
        public void set_role(string role)
        {
            this.role = role;
        }
    }
}
