﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bussiness_Application_1.BL
{
    public class UserBL:PersonBL
    {
        string feedback="";
        public List<BookedSeatsBL> booked_seats_list=new List<BookedSeatsBL>();
        public UserBL(string name, string password, string role) : base(name, password, role)
        {
        }
        public UserBL(string feedback):base("","","")
        {
            this.feedback = feedback;
        }
        public void add_into_booked_seats_list(BookedSeatsBL booked)
        {
            booked_seats_list.Add(booked);
        }
       public void set_feedback(string feedback)
        {
            this.feedback = feedback;
            MessageBox.Show(feedback);
        }
        public string get_feedback()
        {
            return feedback;
        }
        public List<BookedSeatsBL> get_booked_seats_list()
        {
            return booked_seats_list;
        }
       
    }
}
