﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bussiness_Application_1.BL
{
    public class BookedSeatsBL:TicketBL
    {
        int User_fare;
        string choosed_fare;

        public BookedSeatsBL(int user_fare, string choosed_fare,string city,int seats):base(city,seats)
        {
            this.User_fare = user_fare;
            this.choosed_fare = choosed_fare;
        }
        public int get_User_fare()
        {
            return User_fare;
        }
        public string get_choosed_fare()
        {
            return choosed_fare;
        }
        public void set_User_fare(int user_fare)
        {
            this.User_fare = user_fare;
        }
        public void set_choosed_fare(string choosed_fare)
        {
            this.choosed_fare = choosed_fare;
        }
    }
}
