﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bussiness_Application_1.BL
{
    public class AvailableSeatsBL:TicketBL
    {
        int low_fare;
        int high_fare;

        public AvailableSeatsBL(int low_fare, int high_fare, string city, int seats):base(city,seats)
        {
            this.low_fare = low_fare;
            this.high_fare = high_fare;
        }

        public int get_low_fare() 
        {
            return low_fare;
        }
        public int get_high_fare()
        {
            return high_fare;
        }
        public void set_high_fare(int high_fare)
        {
            this.high_fare = high_fare;
        }
        public void set_low_fare(int low_fare)
        {
            this.low_fare = low_fare;
        }
    }
}
