﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Policy;
using System.Text;
using System.Threading.Tasks;

namespace Bussiness_Application_1.BL
{
    public class TicketBL
    {
        protected string city;
        protected int seats;

        public TicketBL(string city, int seats)
        {
            this.city = city;
            this.seats = seats;
        }

        public string get_city()
        {
           return city;
        }
        public int get_seats()
        {
            return seats;
        }
        public void set_city(string city)
        {
            this.city = city;
        }
        public void set_seats(int seats)
        {
            this.seats = seats;
        }
    }
}
