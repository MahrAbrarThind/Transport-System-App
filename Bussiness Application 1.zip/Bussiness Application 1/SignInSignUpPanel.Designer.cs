﻿namespace Bussiness_Application_1
{
    partial class SignInSignUpPanel
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            signInBtn = new Button();
            signUpBtn = new Button();
            SuspendLayout();
            // 
            // signInBtn
            // 
            signInBtn.Location = new Point(99, 242);
            signInBtn.Name = "signInBtn";
            signInBtn.Size = new Size(75, 23);
            signInBtn.TabIndex = 7;
            signInBtn.Text = "SignIn";
            signInBtn.UseVisualStyleBackColor = true;
            signInBtn.Click += signInBtn_Click;
            // 
            // signUpBtn
            // 
            signUpBtn.Location = new Point(99, 103);
            signUpBtn.Name = "signUpBtn";
            signUpBtn.Size = new Size(75, 23);
            signUpBtn.TabIndex = 6;
            signUpBtn.Text = "SignUp";
            signUpBtn.UseVisualStyleBackColor = true;
            signUpBtn.Click += signUpBtn_Click;
            // 
            // SignInSignUpPanel
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackgroundImage = Properties.Resources.copy;
            Controls.Add(signInBtn);
            Controls.Add(signUpBtn);
            Name = "SignInSignUpPanel";
            Size = new Size(286, 521);
            Load += SignInSignUpPanel_Load;
            ResumeLayout(false);
        }

        #endregion
        private Button signInBtn;
        private Button signUpBtn;
    }
}
