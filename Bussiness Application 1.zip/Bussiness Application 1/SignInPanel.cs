﻿using Bussiness_Application_1.BL;
using Bussiness_Application_1.DL;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Bussiness_Application_1
{
    public partial class SignInPanel : UserControl
    {
        Panel panel1;
        Panel panel2;
        public SignInPanel(Panel panel1, Panel panel2)
        {
            InitializeComponent();
            this.panel1 = panel1;
            this.panel2 = panel2;
        }

        private void signInNextBtn_Click(object sender, EventArgs e)
        {
            string name = userNametxtBox.Text;
            string password = userPasswordtxtBox.Text;
            if (PersonDL.chek_user(name, password))
            {
                MessageBox.Show("Valid User:");
                PersonBL person = PersonDL.chek_role(name, password);
                if (person.getrole() == "passenger")
                {
                    UserBL user = PersonDL.chek_role(name,password) as UserBL;
                    panel2.Controls.Clear();
                    panel1.Controls.Clear();
                    UserMenuPanel userMenuPanel = new UserMenuPanel(panel1, panel2, user);
                    panel1.Controls.Add(userMenuPanel);

                }
                if (person.getrole() == "admin")
                {
                    AdminBL admin = PersonDL.chek_role(name, password) as AdminBL;
                    panel2.Controls.Clear();
                    panel1.Controls.Clear();
                    AdminMenuPanel adminMenuPanel = new AdminMenuPanel(panel1, panel2, admin);
                    panel1.Controls.Add(adminMenuPanel);
                }
            }
            else
            {
                MessageBox.Show("InValid User:");
            }
        }

        private void SignInPanel_Load(object sender, EventArgs e)
        {

        }
    }
}
