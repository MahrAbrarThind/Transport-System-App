﻿namespace Bussiness_Application_1
{
    partial class SignInPanel
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            signInNextBtn = new Button();
            userPasswordtxtBox = new TextBox();
            userNametxtBox = new TextBox();
            SignInPagelbl = new Label();
            signInlbl = new Label();
            userNamelbl = new Label();
            SuspendLayout();
            // 
            // signInNextBtn
            // 
            signInNextBtn.Location = new Point(394, 464);
            signInNextBtn.Name = "signInNextBtn";
            signInNextBtn.Size = new Size(75, 23);
            signInNextBtn.TabIndex = 13;
            signInNextBtn.Text = "Next";
            signInNextBtn.UseVisualStyleBackColor = true;
            signInNextBtn.Click += signInNextBtn_Click;
            // 
            // userPasswordtxtBox
            // 
            userPasswordtxtBox.Location = new Point(244, 227);
            userPasswordtxtBox.Name = "userPasswordtxtBox";
            userPasswordtxtBox.Size = new Size(100, 23);
            userPasswordtxtBox.TabIndex = 12;
            // 
            // userNametxtBox
            // 
            userNametxtBox.Location = new Point(244, 160);
            userNametxtBox.Name = "userNametxtBox";
            userNametxtBox.Size = new Size(100, 23);
            userNametxtBox.TabIndex = 11;
            // 
            // SignInPagelbl
            // 
            SignInPagelbl.AutoSize = true;
            SignInPagelbl.Font = new Font("Comic Sans MS", 15.75F, FontStyle.Bold, GraphicsUnit.Point);
            SignInPagelbl.Location = new Point(102, 89);
            SignInPagelbl.Name = "SignInPagelbl";
            SignInPagelbl.Size = new Size(124, 30);
            SignInPagelbl.TabIndex = 10;
            SignInPagelbl.Text = "SignInPage";
            // 
            // signInlbl
            // 
            signInlbl.AutoSize = true;
            signInlbl.Font = new Font("Comic Sans MS", 12F, FontStyle.Bold, GraphicsUnit.Point);
            signInlbl.Location = new Point(42, 227);
            signInlbl.Name = "signInlbl";
            signInlbl.Size = new Size(124, 23);
            signInlbl.TabIndex = 9;
            signInlbl.Text = "UserPassword:";
            // 
            // userNamelbl
            // 
            userNamelbl.AutoSize = true;
            userNamelbl.Font = new Font("Comic Sans MS", 12F, FontStyle.Bold, GraphicsUnit.Point);
            userNamelbl.Location = new Point(42, 160);
            userNamelbl.Name = "userNamelbl";
            userNamelbl.Size = new Size(97, 23);
            userNamelbl.TabIndex = 8;
            userNamelbl.Text = "UserName:";
            // 
            // SignInPanel
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            Controls.Add(signInNextBtn);
            Controls.Add(userPasswordtxtBox);
            Controls.Add(userNametxtBox);
            Controls.Add(SignInPagelbl);
            Controls.Add(signInlbl);
            Controls.Add(userNamelbl);
            Name = "SignInPanel";
            Size = new Size(511, 577);
            Load += SignInPanel_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        private Button signInNextBtn;
        private TextBox userPasswordtxtBox;
        private TextBox userNametxtBox;
        private Label SignInPagelbl;
        private Label signInlbl;
        private Label userNamelbl;
    }
}
