﻿using Bussiness_Application_1.BL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bussiness_Application_1.DL
{
    public class TicketDL
    {
        public static List<AvailableSeatsBL> Available_ticket_list = new List<AvailableSeatsBL>();


        public static int fare_of_user(string city, string Fare, int seats)
        {
            foreach (var a in Available_ticket_list)
            {

                if (a.get_city() == city)
                {
                    if (Fare == "HighFare")
                    {
                        int fare = a.get_high_fare() * seats;
                        MessageBox.Show(fare.ToString(), "your total fare");
                        return fare;

                    }
                    else if (Fare == "LowFare")
                    {
                        int fare = a.get_low_fare() * seats;
                        MessageBox.Show(fare.ToString(), "your total fare");
                        return fare;

                    }

                }
            }
            return 0;
        }
        public static void seats_decreased(BookedSeatsBL booked)
        {
            foreach (var a in Available_ticket_list)
            {
                if (a.get_city() == booked.get_city())
                {
                    int seats = a.get_seats() - booked.get_seats();
                    a.set_seats(seats);

                }
            }
        }
        public static void add_seats(AvailableSeatsBL available)
        {
            Available_ticket_list.Add(available);
        }
        public static void change_fare(string city, int h_fare, int l_fare)
        {
            foreach (var a in Available_ticket_list)
            {
                if (a.get_city() == city)
                {
                    a.set_high_fare(h_fare);
                    a.set_low_fare(l_fare);
                }
            }
        }
        public static bool chek_city(string city1)
        {
            string city = city1;
            bool flag = false;
            foreach (var a in Available_ticket_list)
            {
                if (a.get_city() == city)
                {
                    flag = true;
                    return flag;
                }
            }
            return flag;
        }

        public static void storeCredentials()
        {
            char ch = (char)(200);
            string path = "C:\\Users\\Mahr\\source\\repos\\Bussiness Application 1\\credentials1.txt";
            StreamWriter file = new StreamWriter(path,true);
            foreach (var item in Available_ticket_list)
            {
                file.WriteLine(item.get_city() + ch + item.get_high_fare() + ch + item.get_low_fare() + ch + item.get_seats());
            }
            file.Flush();
            file.Close();
        }

        public static void loadCredentials()
        {
            int number = 200;
            char ch = (char)number;

            string path = "C:\\Users\\Mahr\\source\\repos\\Bussiness Application 1\\credentials1.txt";
            StreamReader filevariable = new StreamReader(path);
            string record;
            if (File.Exists(path))
            {

                while ((record = filevariable.ReadLine()) != null)
                {
                    string[] arry = record.Split(ch);
                    if (arry.Length >= 4)
                    {
                        string city = arry[0];
                        int h_fare = int.Parse(arry[1]);
                        int l_fare = int.Parse(arry[2]);
                        int seats = int.Parse(arry[3]);
                        AvailableSeatsBL available = new AvailableSeatsBL(l_fare, h_fare, city, seats);
                        add_seats(available);
                        MessageBox.Show("File readed successfully");
                    }
                }
                filevariable.Close();
            }
            else
            {
                MessageBox.Show("File not found");
            }

        }

        public static void storeCredentials2()
        {
            char ch = (char)(200);
            string path = "C:\\Users\\Mahr\\source\\repos\\Bussiness Application 1\\credentials2.txt";
            StreamWriter file = new StreamWriter(path, false);
            foreach (var a in PersonDL.person_list)
            {
                if (a is UserBL user1)
                {
                    //UserBL user1 = a as UserBL;
                    foreach (var b in user1.booked_seats_list)
                    {
                        file.WriteLine(user1.getpassword()+ch+user1.getname() + ch + b.get_city() + ch + b.get_seats() + ch + b.get_choosed_fare() + ch + b.get_User_fare());
                    }
                }
            }
            file.Flush();
            file.Close();
        }

        public static void loadCredentials2()
        {
            int number = 200;
            char ch = (char)number;

            string path = "C:\\Users\\Mahr\\source\\repos\\Bussiness Application 1\\credentials2.txt";
            StreamReader filevariable = new StreamReader(path);
            string record;
            if (File.Exists(path))
            {

                while ((record = filevariable.ReadLine()) != null)
                {
                    string[] arry = record.Split(ch);
                    if (arry.Length >= 6)
                    {
                        string password = arry[0];
                        string name = arry[1];
                        string city = arry[2];
                        int booked_seats = int.Parse(arry[3]);
                        string high_low_fare = arry[4];
                        int User_fare = int.Parse(arry[5]);
                        BookedSeatsBL booked = new BookedSeatsBL(User_fare, high_low_fare, city, booked_seats);
                        PersonBL person = PersonDL.chek_role(name, password);
                        if (person.getrole() == "passenger")
                        {
                            UserBL user = person as UserBL;
                            user.add_into_booked_seats_list(booked);
                            MessageBox.Show("File readed successfully");
                        }
                    }
                }
                filevariable.Close();
            }
            else
            {
                MessageBox.Show("File not found");
            }
        }
    }
}
