﻿using Bussiness_Application_1.BL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bussiness_Application_1.DL
{
    public class PersonDL
    {
       public  static List<PersonBL> person_list=new List<PersonBL>();
        public static List<UserBL> feedback_list = new List<UserBL>();
        public static void add_into_list(PersonBL person)
        {
            person_list.Add(person);
        }
        public static void add_feedback(UserBL feedback)
        {
            feedback_list.Add(feedback);
        }
        public static bool  chek_user(string name,string password)
        {
            foreach(var a in person_list)
            {
                if(a.getname() == name && a.getpassword()==password)
                {
                    return true;
                }
            }
            return false;
        }
        public static PersonBL chek_role(string name,string password)
        {
            foreach(var a in person_list)
            {
                if (a.getname()==name&&a.getpassword()==password)
                {
                    return a;
                }
            }
            return null;
        }
        public static bool chek_password(string password)
        {
            foreach(var a in person_list)
            {
                if(a.getpassword()==password)
                {
                    return true;
                }
            }
            return false;
        }

        public static void store_change_credentials(PersonBL obj)
        {
           
/*            file.WriteLine(obj.getname() + ch + obj.getpassword() + ch + obj.getrole());
*/            
        }
        public static void storeCredentials(PersonBL obj)
        {
            char ch = (char)(200);
            string path = "C:\\Users\\Mahr\\source\\repos\\Bussiness Application 1\\credentials.txt";
            StreamWriter file = new StreamWriter(path, false);
            foreach (var a in person_list)
            {
                file.WriteLine(a.getname()+ch+ a.getpassword()+ch+ a.getrole());
            }
            file.Flush();
            file.Close();
        }
        public static void loadCredentials()
        {
            int number = 200;
            char ch = (char)number;

            string path = "C:\\Users\\Mahr\\source\\repos\\Bussiness Application 1\\credentials.txt";
            StreamReader filevariable = new StreamReader(path);
            string record;
            if (File.Exists(path))
            {

                while ((record = filevariable.ReadLine()) != null)
                {
                    string[] arry = record.Split(ch);
                    if (arry.Length >= 3)
                    {
                        string name = arry[0];
                        string password = arry[1];
                        string role = arry[2];
                        if (role == "passenger")
                        {
                            UserBL user = new UserBL(name, password, role);
                            add_into_list(user);
                        }
                        else
                        {
                            AdminBL admin = new AdminBL(name, password, role);
                            add_into_list(admin);
                        }
                    }
                }
                filevariable.Close();
            }
            else
            {
                MessageBox.Show("record not found");
            }


        }

    }
}
