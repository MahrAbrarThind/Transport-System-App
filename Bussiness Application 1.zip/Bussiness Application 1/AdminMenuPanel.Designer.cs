﻿namespace Bussiness_Application_1
{
    partial class AdminMenuPanel
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            exitBtn = new Button();
            chaneFareBtn = new Button();
            viewFeedbackBtn = new Button();
            viewSeatsBtn = new Button();
            addBusBtn = new Button();
            AdminMenulbl = new Label();
            changepasswordBtn = new Button();
            SuspendLayout();
            // 
            // exitBtn
            // 
            exitBtn.Location = new Point(85, 432);
            exitBtn.Name = "exitBtn";
            exitBtn.Size = new Size(119, 28);
            exitBtn.TabIndex = 13;
            exitBtn.Text = "Exit";
            exitBtn.UseVisualStyleBackColor = true;
            exitBtn.Click += exitBtn_Click;
            // 
            // chaneFareBtn
            // 
            chaneFareBtn.Location = new Point(85, 303);
            chaneFareBtn.Name = "chaneFareBtn";
            chaneFareBtn.Size = new Size(119, 28);
            chaneFareBtn.TabIndex = 12;
            chaneFareBtn.Text = "ChangeFare";
            chaneFareBtn.UseVisualStyleBackColor = true;
            chaneFareBtn.Click += chaneFareBtn_Click;
            // 
            // viewFeedbackBtn
            // 
            viewFeedbackBtn.Location = new Point(85, 246);
            viewFeedbackBtn.Name = "viewFeedbackBtn";
            viewFeedbackBtn.Size = new Size(119, 28);
            viewFeedbackBtn.TabIndex = 11;
            viewFeedbackBtn.Text = "ViewFeedBack";
            viewFeedbackBtn.UseVisualStyleBackColor = true;
            viewFeedbackBtn.Click += viewFeedbackBtn_Click;
            // 
            // viewSeatsBtn
            // 
            viewSeatsBtn.Location = new Point(85, 179);
            viewSeatsBtn.Name = "viewSeatsBtn";
            viewSeatsBtn.Size = new Size(119, 27);
            viewSeatsBtn.TabIndex = 10;
            viewSeatsBtn.Text = "ViewSeats";
            viewSeatsBtn.UseVisualStyleBackColor = true;
            viewSeatsBtn.Click += viewSeatsBtn_Click;
            // 
            // addBusBtn
            // 
            addBusBtn.Location = new Point(85, 123);
            addBusBtn.Name = "addBusBtn";
            addBusBtn.Size = new Size(119, 28);
            addBusBtn.TabIndex = 9;
            addBusBtn.Text = "AddBus";
            addBusBtn.UseVisualStyleBackColor = true;
            addBusBtn.Click += addBusBtn_Click;
            // 
            // AdminMenulbl
            // 
            AdminMenulbl.AutoSize = true;
            AdminMenulbl.Font = new Font("Comic Sans MS", 21.75F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point);
            AdminMenulbl.Location = new Point(53, 46);
            AdminMenulbl.Name = "AdminMenulbl";
            AdminMenulbl.Size = new Size(174, 41);
            AdminMenulbl.TabIndex = 8;
            AdminMenulbl.Text = "AdminMenu";
            // 
            // changepasswordBtn
            // 
            changepasswordBtn.Location = new Point(85, 360);
            changepasswordBtn.Name = "changepasswordBtn";
            changepasswordBtn.Size = new Size(119, 29);
            changepasswordBtn.TabIndex = 14;
            changepasswordBtn.Text = "ChangePassword";
            changepasswordBtn.UseVisualStyleBackColor = true;
            changepasswordBtn.Click += changepasswordBtn_Click;
            // 
            // AdminMenuPanel
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackgroundImage = Properties.Resources.copy;
            Controls.Add(changepasswordBtn);
            Controls.Add(exitBtn);
            Controls.Add(chaneFareBtn);
            Controls.Add(viewFeedbackBtn);
            Controls.Add(viewSeatsBtn);
            Controls.Add(addBusBtn);
            Controls.Add(AdminMenulbl);
            Name = "AdminMenuPanel";
            Size = new Size(289, 526);
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button exitBtn;
        private Button chaneFareBtn;
        private Button viewFeedbackBtn;
        private Button viewSeatsBtn;
        private Button addBusBtn;
        private Label AdminMenulbl;
        private Button changepasswordBtn;
    }
}
