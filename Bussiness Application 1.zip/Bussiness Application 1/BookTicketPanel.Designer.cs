﻿namespace Bussiness_Application_1
{
    partial class BookTicketPanel
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            DoneBtn = new Button();
            farelbl = new Label();
            FareComboBox = new ComboBox();
            SeatsComboBox = new ComboBox();
            seatslbl = new Label();
            chooseCitylbl = new Label();
            CityComboBox = new ComboBox();
            SuspendLayout();
            // 
            // DoneBtn
            // 
            DoneBtn.Location = new Point(356, 389);
            DoneBtn.Name = "DoneBtn";
            DoneBtn.Size = new Size(75, 23);
            DoneBtn.TabIndex = 13;
            DoneBtn.Text = "Done";
            DoneBtn.UseVisualStyleBackColor = true;
            DoneBtn.Click += DoneBtn_Click;
            // 
            // farelbl
            // 
            farelbl.AutoSize = true;
            farelbl.Location = new Point(80, 290);
            farelbl.Name = "farelbl";
            farelbl.Size = new Size(72, 15);
            farelbl.TabIndex = 12;
            farelbl.Text = "Choose Fare";
            // 
            // FareComboBox
            // 
            FareComboBox.FormattingEnabled = true;
            FareComboBox.Items.AddRange(new object[] { "HighFare", "LowFare" });
            FareComboBox.Location = new Point(182, 282);
            FareComboBox.Name = "FareComboBox";
            FareComboBox.Size = new Size(121, 23);
            FareComboBox.TabIndex = 11;
            // 
            // SeatsComboBox
            // 
            SeatsComboBox.FormattingEnabled = true;
            SeatsComboBox.Items.AddRange(new object[] { "1", "2" });
            SeatsComboBox.Location = new Point(182, 190);
            SeatsComboBox.Name = "SeatsComboBox";
            SeatsComboBox.Size = new Size(121, 23);
            SeatsComboBox.TabIndex = 10;
            SeatsComboBox.SelectedIndexChanged += SeatsComboBox_SelectedIndexChanged;
            // 
            // seatslbl
            // 
            seatslbl.AutoSize = true;
            seatslbl.Location = new Point(80, 190);
            seatslbl.Name = "seatslbl";
            seatslbl.Size = new Size(68, 15);
            seatslbl.TabIndex = 9;
            seatslbl.Text = "SelectSeats:";
            // 
            // chooseCitylbl
            // 
            chooseCitylbl.AutoSize = true;
            chooseCitylbl.Location = new Point(80, 116);
            chooseCitylbl.Name = "chooseCitylbl";
            chooseCitylbl.Size = new Size(71, 15);
            chooseCitylbl.TabIndex = 8;
            chooseCitylbl.Text = "ChooseCity:";
            // 
            // CityComboBox
            // 
            CityComboBox.FormattingEnabled = true;
            CityComboBox.Location = new Point(182, 113);
            CityComboBox.Name = "CityComboBox";
            CityComboBox.Size = new Size(121, 23);
            CityComboBox.TabIndex = 7;
            CityComboBox.SelectedIndexChanged += CityComboBox_SelectedIndexChanged;
            // 
            // BookTicketPanel
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            Controls.Add(DoneBtn);
            Controls.Add(farelbl);
            Controls.Add(FareComboBox);
            Controls.Add(SeatsComboBox);
            Controls.Add(seatslbl);
            Controls.Add(chooseCitylbl);
            Controls.Add(CityComboBox);
            Name = "BookTicketPanel";
            Size = new Size(511, 524);
            Load += BookTicketPanel_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button DoneBtn;
        private Label farelbl;
        private ComboBox FareComboBox;
        private ComboBox SeatsComboBox;
        private Label seatslbl;
        private Label chooseCitylbl;
        private ComboBox CityComboBox;
    }
}
