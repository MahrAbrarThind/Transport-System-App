﻿namespace Bussiness_Application_1
{
    partial class ChangeFarePanel
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            DoneBtn = new Button();
            lowFaretxtBox = new TextBox();
            highFaretxtBox = new TextBox();
            CityComboBox = new ComboBox();
            LowFarelbl = new Label();
            HighFarelbl = new Label();
            Citylbl = new Label();
            SuspendLayout();
            // 
            // DoneBtn
            // 
            DoneBtn.Location = new Point(331, 415);
            DoneBtn.Name = "DoneBtn";
            DoneBtn.Size = new Size(75, 23);
            DoneBtn.TabIndex = 13;
            DoneBtn.Text = "Done";
            DoneBtn.UseVisualStyleBackColor = true;
            DoneBtn.Click += DoneBtn_Click;
            // 
            // lowFaretxtBox
            // 
            lowFaretxtBox.Location = new Point(178, 280);
            lowFaretxtBox.Name = "lowFaretxtBox";
            lowFaretxtBox.Size = new Size(121, 23);
            lowFaretxtBox.TabIndex = 12;
            // 
            // highFaretxtBox
            // 
            highFaretxtBox.Location = new Point(178, 196);
            highFaretxtBox.Name = "highFaretxtBox";
            highFaretxtBox.Size = new Size(121, 23);
            highFaretxtBox.TabIndex = 11;
            // 
            // CityComboBox
            // 
            CityComboBox.FormattingEnabled = true;
            CityComboBox.Location = new Point(178, 128);
            CityComboBox.Name = "CityComboBox";
            CityComboBox.Size = new Size(121, 23);
            CityComboBox.TabIndex = 10;
            // 
            // LowFarelbl
            // 
            LowFarelbl.AutoSize = true;
            LowFarelbl.Location = new Point(68, 288);
            LowFarelbl.Name = "LowFarelbl";
            LowFarelbl.Size = new Size(87, 15);
            LowFarelbl.TabIndex = 9;
            LowFarelbl.Text = "Enter Low Fare:";
            // 
            // HighFarelbl
            // 
            HighFarelbl.AutoSize = true;
            HighFarelbl.Location = new Point(68, 204);
            HighFarelbl.Name = "HighFarelbl";
            HighFarelbl.Size = new Size(91, 15);
            HighFarelbl.TabIndex = 8;
            HighFarelbl.Text = "Enter High Fare:";
            // 
            // Citylbl
            // 
            Citylbl.AutoSize = true;
            Citylbl.Location = new Point(68, 136);
            Citylbl.Name = "Citylbl";
            Citylbl.Size = new Size(62, 15);
            Citylbl.TabIndex = 7;
            Citylbl.Text = "SelectCity:";
            // 
            // ChangeFarePanel
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            Controls.Add(DoneBtn);
            Controls.Add(lowFaretxtBox);
            Controls.Add(highFaretxtBox);
            Controls.Add(CityComboBox);
            Controls.Add(LowFarelbl);
            Controls.Add(HighFarelbl);
            Controls.Add(Citylbl);
            Name = "ChangeFarePanel";
            Size = new Size(540, 551);
            Load += ChangeFarePanel_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button DoneBtn;
        private TextBox lowFaretxtBox;
        private TextBox highFaretxtBox;
        private ComboBox CityComboBox;
        private Label LowFarelbl;
        private Label HighFarelbl;
        private Label Citylbl;
    }
}
