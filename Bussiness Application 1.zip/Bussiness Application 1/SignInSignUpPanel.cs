﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Bussiness_Application_1
{
    public partial class SignInSignUpPanel : UserControl
    {
        Panel panel1;
        Panel panel2;
        public SignInSignUpPanel(Panel panel1, Panel panel2)
        {
            InitializeComponent();
            this.panel1 = panel1;
            this.panel2 = panel2;
        }

        private void signUpBtn_Click(object sender, EventArgs e)
        {
            SignUpPanel signUpPanel = new SignUpPanel(panel1, panel2);
            panel2.Controls.Clear();
            panel2.Controls.Add(signUpPanel);
        }

        private void signInBtn_Click(object sender, EventArgs e)
        {
            SignInPanel signInPanel = new SignInPanel(panel1, panel2);
            panel2.Controls.Clear();
            panel2.Controls.Add(signInPanel);
        }

        private void SignInSignUpPanel_Load(object sender, EventArgs e)
        {

        }
    }
}
