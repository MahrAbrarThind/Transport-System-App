﻿using Bussiness_Application_1.BL;
using Bussiness_Application_1.DL;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Bussiness_Application_1
{
    public partial class ChangeFarePanel : UserControl
    {
        Panel panel1;
        Panel panel2;
        AdminBL admin;
        public ChangeFarePanel(Panel panel1,Panel panel2,AdminBL admin)
        {
            this.panel1 = panel1;
            this.panel2 = panel2;
            this.admin = admin;
            InitializeComponent();
        }

        private void ChangeFarePanel_Load(object sender, EventArgs e)
        {
            foreach(var a in TicketDL.Available_ticket_list)
            {
                CityComboBox.Items.Add(a.get_city());
            }
        }

        private void DoneBtn_Click(object sender, EventArgs e)
        {
            string city = CityComboBox.Text;
            int high_fare = int.Parse(highFaretxtBox.Text);
            int low_fare = int.Parse(lowFaretxtBox.Text);
            if(TicketDL.chek_city(city))
            {
                TicketDL.change_fare(city, high_fare, low_fare);
                TicketDL.storeCredentials();
            }
            else
            {
                MessageBox.Show("city not found;");
            }
        }
    }
}
