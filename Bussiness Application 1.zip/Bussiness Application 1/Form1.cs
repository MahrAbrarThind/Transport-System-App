using Bussiness_Application_1.DL;

namespace Bussiness_Application_1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            PersonDL.loadCredentials();
            TicketDL.loadCredentials();
            TicketDL.loadCredentials2();
            panel1.Controls.Clear();
            SignInSignUpPanel signInSignUpPanel = new SignInSignUpPanel(panel1, panel2);
            LogoPanel logoPanel = new LogoPanel();
            panel1.Controls.Add(signInSignUpPanel);
            panel2.Controls.Add(logoPanel);
        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }
    }
}