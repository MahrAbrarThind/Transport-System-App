﻿using Bussiness_Application_1.BL;
using Microsoft.VisualBasic.ApplicationServices;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Bussiness_Application_1
{
    public partial class AdminChangePasswordPanel : UserControl
    {
        Panel panel1;
        Panel panel2;
        AdminBL admin;
        public AdminChangePasswordPanel(Panel panel1, Panel panel2, AdminBL admin)
        {
            this.panel1 = panel1;
            this.panel2 = panel2;
            this.admin = admin;
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string password = textBox1.Text;
            if (admin.getpassword() == password)
            {
                AdminChangePasswordNext adminchangePasswordNextPanel = new AdminChangePasswordNext(panel1, panel2, admin);
                panel2.Controls.Clear();
                panel2.Controls.Add(adminchangePasswordNextPanel);
            }
            else
            {
                MessageBox.Show("Password Not Found");
            }
        }
    }
}
