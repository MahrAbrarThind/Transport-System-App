﻿using Bussiness_Application_1.BL;
using Bussiness_Application_1.DL;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Bussiness_Application_1
{
    public partial class UserSeeFarePanel : UserControl
    {
        DataTable table = new DataTable();
        Panel panel1;
        Panel panel2;
        UserBL user;
        public UserSeeFarePanel(Panel panel1,Panel panel2,UserBL user)
        {
            this.panel1 = panel1;
            this.panel2=panel2;
            this.user = user;
            InitializeComponent();
        }

        private void UserSeeFarePanel_Load(object sender, EventArgs e)
        {

            table.Columns.Add("City", typeof(string));
            table.Columns.Add("High Fare", typeof(int));
            table.Columns.Add("Low Fare", typeof(int));
            table.Columns.Add("Seats", typeof(int));
            UserSeeFareDataGridView.DataSource = table;
            foreach(var a in TicketDL.Available_ticket_list)
            {
                table.Rows.Add(a.get_city(), a.get_high_fare(), a.get_low_fare(), a.get_seats() + Environment.NewLine);
            }
        }
    }
}
