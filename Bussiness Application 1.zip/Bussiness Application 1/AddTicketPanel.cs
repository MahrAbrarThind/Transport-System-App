﻿using Bussiness_Application_1.BL;
using Bussiness_Application_1.DL;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Bussiness_Application_1
{
    public partial class AddTicketPanel : UserControl
    {
        Panel panel1;
        Panel panel2;
        AdminBL admin;
        public AddTicketPanel(Panel panel1, Panel panel2, AdminBL admin)
        {
            InitializeComponent();
            this.panel1 = panel1;
            this.panel2 = panel2;
            this.admin = admin;
        }

        private void AddTicketPanel_Load(object sender, EventArgs e)
        {

        }

        private void DoneBtn_Click(object sender, EventArgs e)
        {
            string city = CityTxtBox.Text;
            int seats = int.Parse(SeatsTxtBox.Text);
            int high_fare = int.Parse(HighFareTxtBox.Text);
            int low_fare = int.Parse(LowFareTxtBox.Text);
            AvailableSeatsBL available = new AvailableSeatsBL(low_fare, high_fare, city, seats);
            TicketDL.add_seats(available);
            TicketDL.storeCredentials();
            MessageBox.Show("Bus Added Successfully");
            empty();
        }
        private void empty()
        {
            CityTxtBox.Text = "";
            SeatsTxtBox.Text = "";
            HighFareTxtBox.Text = "";
            LowFareTxtBox.Text = "";
        }
    }
}
