﻿using Bussiness_Application_1.BL;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Bussiness_Application_1
{
    public partial class UserPayFarePanel : UserControl
    {
        Panel panel1;
        Panel panel2;
        BookedSeatsBL booked;
        UserBL user;
        public UserPayFarePanel(Panel panel1,Panel panel2,BookedSeatsBL booked,UserBL user)
        {
            this.panel1 = panel1;
            this.panel2 = panel2;
            this.booked = booked;
            this.user = user;
            InitializeComponent();
        }

        private void PayFareDoneBtn_Click(object sender, EventArgs e)
        {
            int fare = int.Parse(userPayFaretxtBox.Text);
            if(fare==booked.get_User_fare())
            {
                UserMenuPanel userMenuPanel = new UserMenuPanel(panel1, panel2, user);
                MessageBox.Show("Thanks");
                panel2.Controls.Clear();
                LogoPanel logo = new LogoPanel();
                panel2.Controls.Add(logo);
                panel1.Controls.Add(userMenuPanel);
            }
            else
            {
                MessageBox.Show("The fare is invalid");
            }
        }

        private void UserPayFarePanel_Load(object sender, EventArgs e)
        {

        }
    }
}
