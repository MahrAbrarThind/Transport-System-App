﻿namespace Bussiness_Application_1
{
    partial class AddTicketPanel
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            LowFarelbl = new Label();
            HighFarelbl = new Label();
            Seatslbl = new Label();
            Citylbl = new Label();
            DoneBtn = new Button();
            LowFareTxtBox = new TextBox();
            HighFareTxtBox = new TextBox();
            SeatsTxtBox = new TextBox();
            CityTxtBox = new TextBox();
            addTicketlbl = new Label();
            SuspendLayout();
            // 
            // LowFarelbl
            // 
            LowFarelbl.AutoSize = true;
            LowFarelbl.Location = new Point(85, 384);
            LowFarelbl.Name = "LowFarelbl";
            LowFarelbl.Size = new Size(81, 15);
            LowFarelbl.TabIndex = 19;
            LowFarelbl.Text = "EnterLowFare:";
            // 
            // HighFarelbl
            // 
            HighFarelbl.AutoSize = true;
            HighFarelbl.Location = new Point(85, 317);
            HighFarelbl.Name = "HighFarelbl";
            HighFarelbl.Size = new Size(85, 15);
            HighFarelbl.TabIndex = 18;
            HighFarelbl.Text = "EnterHighFare:";
            // 
            // Seatslbl
            // 
            Seatslbl.AutoSize = true;
            Seatslbl.Location = new Point(85, 248);
            Seatslbl.Name = "Seatslbl";
            Seatslbl.Size = new Size(64, 15);
            Seatslbl.TabIndex = 17;
            Seatslbl.Text = "EnterSeats:";
            // 
            // Citylbl
            // 
            Citylbl.AutoSize = true;
            Citylbl.Location = new Point(85, 186);
            Citylbl.Name = "Citylbl";
            Citylbl.Size = new Size(58, 15);
            Citylbl.TabIndex = 16;
            Citylbl.Text = "EnterCity:";
            // 
            // DoneBtn
            // 
            DoneBtn.Location = new Point(345, 435);
            DoneBtn.Name = "DoneBtn";
            DoneBtn.Size = new Size(75, 23);
            DoneBtn.TabIndex = 15;
            DoneBtn.Text = "Done";
            DoneBtn.UseVisualStyleBackColor = true;
            DoneBtn.Click += DoneBtn_Click;
            // 
            // LowFareTxtBox
            // 
            LowFareTxtBox.Location = new Point(181, 381);
            LowFareTxtBox.Name = "LowFareTxtBox";
            LowFareTxtBox.Size = new Size(100, 23);
            LowFareTxtBox.TabIndex = 14;
            // 
            // HighFareTxtBox
            // 
            HighFareTxtBox.Location = new Point(181, 309);
            HighFareTxtBox.Name = "HighFareTxtBox";
            HighFareTxtBox.Size = new Size(100, 23);
            HighFareTxtBox.TabIndex = 13;
            // 
            // SeatsTxtBox
            // 
            SeatsTxtBox.Location = new Point(181, 240);
            SeatsTxtBox.Name = "SeatsTxtBox";
            SeatsTxtBox.Size = new Size(100, 23);
            SeatsTxtBox.TabIndex = 12;
            // 
            // CityTxtBox
            // 
            CityTxtBox.Location = new Point(181, 178);
            CityTxtBox.Name = "CityTxtBox";
            CityTxtBox.Size = new Size(100, 23);
            CityTxtBox.TabIndex = 11;
            // 
            // addTicketlbl
            // 
            addTicketlbl.AutoSize = true;
            addTicketlbl.Font = new Font("Comic Sans MS", 24F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point);
            addTicketlbl.Location = new Point(103, 91);
            addTicketlbl.Name = "addTicketlbl";
            addTicketlbl.Size = new Size(286, 45);
            addTicketlbl.TabIndex = 10;
            addTicketlbl.Text = "Add Ticket Menu";
            // 
            // AddTicketPanel
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            Controls.Add(LowFarelbl);
            Controls.Add(HighFarelbl);
            Controls.Add(Seatslbl);
            Controls.Add(Citylbl);
            Controls.Add(DoneBtn);
            Controls.Add(LowFareTxtBox);
            Controls.Add(HighFareTxtBox);
            Controls.Add(SeatsTxtBox);
            Controls.Add(CityTxtBox);
            Controls.Add(addTicketlbl);
            Name = "AddTicketPanel";
            Size = new Size(582, 548);
            Load += AddTicketPanel_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label LowFarelbl;
        private Label HighFarelbl;
        private Label Seatslbl;
        private Label Citylbl;
        private Button DoneBtn;
        private TextBox LowFareTxtBox;
        private TextBox HighFareTxtBox;
        private TextBox SeatsTxtBox;
        private TextBox CityTxtBox;
        private Label addTicketlbl;
    }
}
