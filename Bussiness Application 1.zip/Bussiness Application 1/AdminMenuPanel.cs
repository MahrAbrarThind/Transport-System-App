﻿using Bussiness_Application_1.BL;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Bussiness_Application_1
{
    public partial class AdminMenuPanel : UserControl
    {
        Panel panel1;
        Panel panel2;
        AdminBL admin;
        public AdminMenuPanel(Panel panel1, Panel panel2, AdminBL admin)
        {
            this.panel1 = panel1;
            this.panel2 = panel2;
            this.admin = admin;
            InitializeComponent();
        }

        private void exitBtn_Click(object sender, EventArgs e)
        {
            SignInSignUpPanel signInSignUpPanel = new SignInSignUpPanel(panel1, panel2);
            panel1.Controls.Clear();
            panel1.Controls.Add(signInSignUpPanel);
        }

        private void addBusBtn_Click(object sender, EventArgs e)
        {
            AddTicketPanel addTicketPanel = new AddTicketPanel(panel1, panel2, admin);
            panel2.Controls.Clear();
            panel2.Controls.Add(addTicketPanel);

        }

        private void viewFeedbackBtn_Click(object sender, EventArgs e)
        {
            ViewFeedBackPanel viewFeedBackPanel = new ViewFeedBackPanel(panel1, panel2, admin);
            panel2.Controls.Clear();
            panel2.Controls.Add(viewFeedBackPanel);
        }

        private void viewSeatsBtn_Click(object sender, EventArgs e)
        {
            AdminSeeFarePanel adminSeeFarePanel = new AdminSeeFarePanel(panel1, panel2, admin);
            panel2.Controls.Clear();
            panel2.Controls.Add(adminSeeFarePanel);
        }

        private void chaneFareBtn_Click(object sender, EventArgs e)
        {
            ChangeFarePanel changeFarePanel = new ChangeFarePanel(panel1, panel2, admin);
            panel2.Controls.Clear();
            panel2.Controls.Add(changeFarePanel);
        }

        private void changepasswordBtn_Click(object sender, EventArgs e)
        {
            AdminChangePasswordPanel adminChangePasswordPanel = new AdminChangePasswordPanel(panel1, panel2, admin);
            panel2.Controls.Clear();
            panel2.Controls.Add(adminChangePasswordPanel);
        }
    }
}
