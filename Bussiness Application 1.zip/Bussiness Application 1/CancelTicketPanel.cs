﻿using Bussiness_Application_1.BL;
using Bussiness_Application_1.DL;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Bussiness_Application_1
{
    public partial class CancelTicketPanel : UserControl
    {
        Panel panel1;
        Panel panel2;
        UserBL user;
        DataTable table = new DataTable();
        public CancelTicketPanel(Panel panel1, Panel panel2, UserBL user)
        {
            this.panel1 = panel1;
            this.panel2 = panel2;
            this.user = user;
            InitializeComponent();
        }


        private void CancelTicketPanel_Load(object sender, EventArgs e)
        {
            table.Columns.Add("City", typeof(string));
            table.Columns.Add("Seats", typeof(int));
            dataGridView1.DataSource = table;
            foreach (var a in user.booked_seats_list)
            {
                table.Rows.Add(a.get_city(), a.get_seats());
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            foreach (var a in TicketDL.Available_ticket_list)
            {
                foreach (var b in user.booked_seats_list)
                {
                    if (b.get_seats() > 0)
                    {
                        if (a.get_city() == b.get_city())
                        {
                            int seats = a.get_seats() + b.get_seats();
                            a.set_seats(seats);
                            b.set_seats(0);
                        }
                    }
                }
            }
            TicketDL.storeCredentials();
            TicketDL.storeCredentials2();
        }
    }
}
