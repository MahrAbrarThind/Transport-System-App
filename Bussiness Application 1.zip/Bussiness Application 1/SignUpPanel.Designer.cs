﻿namespace Bussiness_Application_1
{
    partial class SignUpPanel
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            signUpNextBtn = new Button();
            userPasswordtxtBox = new TextBox();
            userNametxtBox = new TextBox();
            signUpPagelbl = new Label();
            userRolelbl = new Label();
            Passwordlbl = new Label();
            userNamelbl = new Label();
            adminRBtn = new RadioButton();
            PassengerRBtn = new RadioButton();
            SuspendLayout();
            // 
            // signUpNextBtn
            // 
            signUpNextBtn.Location = new Point(447, 452);
            signUpNextBtn.Name = "signUpNextBtn";
            signUpNextBtn.Size = new Size(75, 23);
            signUpNextBtn.TabIndex = 16;
            signUpNextBtn.Text = "Next";
            signUpNextBtn.UseVisualStyleBackColor = true;
            signUpNextBtn.Click += signUpNextBtn_Click;
            // 
            // userPasswordtxtBox
            // 
            userPasswordtxtBox.Location = new Point(227, 240);
            userPasswordtxtBox.Name = "userPasswordtxtBox";
            userPasswordtxtBox.Size = new Size(100, 23);
            userPasswordtxtBox.TabIndex = 14;
            // 
            // userNametxtBox
            // 
            userNametxtBox.Location = new Point(227, 170);
            userNametxtBox.Name = "userNametxtBox";
            userNametxtBox.Size = new Size(100, 23);
            userNametxtBox.TabIndex = 13;
            // 
            // signUpPagelbl
            // 
            signUpPagelbl.AutoSize = true;
            signUpPagelbl.BackColor = SystemColors.AppWorkspace;
            signUpPagelbl.Font = new Font("Comic Sans MS", 21.75F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point);
            signUpPagelbl.Location = new Point(135, 51);
            signUpPagelbl.Name = "signUpPagelbl";
            signUpPagelbl.Size = new Size(175, 41);
            signUpPagelbl.TabIndex = 12;
            signUpPagelbl.Text = "SingUpPage";
            // 
            // userRolelbl
            // 
            userRolelbl.AutoSize = true;
            userRolelbl.Font = new Font("Comic Sans MS", 12F, FontStyle.Bold, GraphicsUnit.Point);
            userRolelbl.Location = new Point(55, 308);
            userRolelbl.Name = "userRolelbl";
            userRolelbl.Size = new Size(85, 23);
            userRolelbl.TabIndex = 11;
            userRolelbl.Text = "UserRole:";
            // 
            // Passwordlbl
            // 
            Passwordlbl.AutoSize = true;
            Passwordlbl.Font = new Font("Comic Sans MS", 12F, FontStyle.Bold, GraphicsUnit.Point);
            Passwordlbl.Location = new Point(55, 248);
            Passwordlbl.Name = "Passwordlbl";
            Passwordlbl.Size = new Size(124, 23);
            Passwordlbl.TabIndex = 10;
            Passwordlbl.Text = "UserPassword:";
            // 
            // userNamelbl
            // 
            userNamelbl.AutoSize = true;
            userNamelbl.Font = new Font("Comic Sans MS", 12F, FontStyle.Bold, GraphicsUnit.Point);
            userNamelbl.Location = new Point(55, 170);
            userNamelbl.Name = "userNamelbl";
            userNamelbl.Size = new Size(97, 23);
            userNamelbl.TabIndex = 9;
            userNamelbl.Text = "UserName:";
            // 
            // adminRBtn
            // 
            adminRBtn.AutoSize = true;
            adminRBtn.Location = new Point(227, 308);
            adminRBtn.Name = "adminRBtn";
            adminRBtn.Size = new Size(61, 19);
            adminRBtn.TabIndex = 18;
            adminRBtn.TabStop = true;
            adminRBtn.Text = "Admin";
            adminRBtn.UseVisualStyleBackColor = true;
            adminRBtn.CheckedChanged += adminRBtn_CheckedChanged;
            // 
            // PassengerRBtn
            // 
            PassengerRBtn.AutoSize = true;
            PassengerRBtn.Location = new Point(227, 352);
            PassengerRBtn.Name = "PassengerRBtn";
            PassengerRBtn.Size = new Size(78, 19);
            PassengerRBtn.TabIndex = 19;
            PassengerRBtn.TabStop = true;
            PassengerRBtn.Text = "Passenger";
            PassengerRBtn.UseVisualStyleBackColor = true;
            PassengerRBtn.CheckedChanged += PassengerRBtn_CheckedChanged;
            // 
            // SignUpPanel
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            Controls.Add(PassengerRBtn);
            Controls.Add(adminRBtn);
            Controls.Add(signUpNextBtn);
            Controls.Add(userPasswordtxtBox);
            Controls.Add(userNametxtBox);
            Controls.Add(signUpPagelbl);
            Controls.Add(userRolelbl);
            Controls.Add(Passwordlbl);
            Controls.Add(userNamelbl);
            Name = "SignUpPanel";
            Size = new Size(540, 568);
            Load += SignUpPanel_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        private Button signUpNextBtn;
        private TextBox userPasswordtxtBox;
        private TextBox userNametxtBox;
        private Label signUpPagelbl;
        private Label userRolelbl;
        private Label Passwordlbl;
        private Label userNamelbl;
        private RadioButton adminRBtn;
        private RadioButton PassengerRBtn;
    }
}
