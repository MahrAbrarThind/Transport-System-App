﻿using Bussiness_Application_1.BL;
using Bussiness_Application_1.DL;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.StartPanel;

namespace Bussiness_Application_1
{
    public partial class SignUpPanel : UserControl
    {
        Panel panel1;
        Panel panel2;
        public SignUpPanel(Panel panel1, Panel panel2)
        {
            InitializeComponent();
            this.panel1 = panel1;
            this.panel2 = panel2;
        }

        private void SignUpPanel_Load(object sender, EventArgs e)
        {


        }
        string role;

        private void signUpNextBtn_Click(object sender, EventArgs e)
        {
            string Name = userNametxtBox.Text.Trim();
            string Password = userPasswordtxtBox.Text.Trim();
            if (string.IsNullOrEmpty(Name)||string.IsNullOrEmpty(Password))
            {
                MessageBox.Show("You Entered wrong credentials");
            }
            else
            {
                if (PersonDL.chek_password(Password))
                {
                    MessageBox.Show("Sorry this password cannot be used:");
                }
                else
                {

                    string Role = role;
                    if (Role == "passenger")
                    {
                        UserBL user = new UserBL(Name, Password, Role);
                        PersonDL.add_into_list(user);
                        MessageBox.Show(Name, Password);
                        MessageBox.Show("user added successfully:");
                        PersonDL.storeCredentials(user);
                        SignInPanel signInPanel = new SignInPanel(panel1, panel2);
                        panel2.Controls.Clear();
                        panel2.Controls.Add(signInPanel);

                    }
                    else
                    {
                        bool flag = false;
                        foreach (var a in PersonDL.person_list)
                        {
                            if (a.getrole() == "admin")
                            {
                                flag = true;
                                break;
                            }

                        }
                        if (flag == true)
                        {
                            MessageBox.Show("Sorry only one admin can Sign UP");
                        }
                        else
                        {
                            AdminBL admin = new AdminBL(Name, Password, Role);
                            PersonDL.add_into_list(admin);
                            PersonDL.storeCredentials(admin);
                            MessageBox.Show("admin added successfully:");
                            SignInPanel signIn = new SignInPanel(panel1, panel2);
                            panel2.Controls.Clear();
                            panel2.Controls.Add(signIn);
                            empty_textbox();
                        }
                    }
                }


            }

        }
        private void empty_textbox()
        {
            userNametxtBox.Text = "";
            userPasswordtxtBox.Text = "";
        }

        private void adminRBtn_CheckedChanged(object sender, EventArgs e)
        {
            role = "admin";
        }

        private void PassengerRBtn_CheckedChanged(object sender, EventArgs e)
        {
            role = "passenger";
        }
    }
}
